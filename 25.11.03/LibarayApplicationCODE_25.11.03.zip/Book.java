
/**
 * Book 클래스의 설명을 작성하세요.
 *
 * @author (작성자 이름)
 * @version (버전 번호 또는 작성한 날짜)
 */
public class Book
{
    private String title;
    private String author;
    private int catalogueNumber;

    public Book(String title, String author, int catalogueNumber){
        this.title = title;
        this.author = author;
        this.catalogueNumber = catalogueNumber;
    }
    
    public boolean checkBook(){
        return true;
    }
    
    public void display(){
        System.out.println("책 제목: " + title + "저자: " + author + "고유번호: " + catalogueNumber);
    }
}
